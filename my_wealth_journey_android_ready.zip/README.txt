MY WEALTH JOURNEY — Android-friendly PWA prototype

1. Put these three files on a web host using HTTPS (for example, GitHub Pages, Netlify, or another static host).
2. Open the hosted index.html in Chrome on Android.
3. Use Chrome's menu and choose "Add to Home screen" / "Install app".
4. The app stores the entered savings and investment totals locally on the device.

Included:
- Savings, investment and net-worth dashboard
- $10K / $100K / $1M challenges
- Monthly investment projection with compound growth
- Local storage
- Installable PWA shell
